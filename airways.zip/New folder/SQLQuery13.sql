Create table CreditCard
(flightId varchar(10),PassportNo varchar(20),Cardnumber bigint,expDate varchar(10),CVV int,Total_tickets int,Total_Amount int,PNRno varchar(10))