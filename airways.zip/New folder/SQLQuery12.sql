select * from flight
Alter table flight alter column price int