create table adminTable
(AdminId varchar(10),AdminPassword varchar(10),depID varchar(10))


insert into adminTable values('Admin1','Admin001','CN001')
insert into adminTable values('Admin2','Admin002','CN002')
insert into adminTable values('Admin3','Admin003','CN003')