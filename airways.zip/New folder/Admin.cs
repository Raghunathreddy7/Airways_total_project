﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminLb
{
    public class Admin
    {
        public string AdminId { get; set; }
        public string AdminPassword { get; set; }
        public string depID { get; set; }
    }
}
